import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { SpotListComponent } from './spot-list/spot-list.component';
import { SpotServiceService } from './spot-service.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { SeparatePipe } from './separate.pipe';
import { SpotItemComponent } from './spot-item/spot-item.component';
import { SpotDetailComponent } from './spot-detail/spot-detail.component';
import { MapsUrlPipe } from './maps-url.pipe';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    // path: '' : cela signifie que cette route correspond à la racine de l'application, c'est-à-dire à l'URL de base sans aucun segment de chemin supplémentaire.
    // pathMatch: 'full' : cela indique que la route doit correspondre exactement à la chaîne de caractères spécifiée dans path. Si ce n'est pas le cas, Angular va chercher d'autres routes pour correspondre à l'URL.
    // redirectTo: '/app-spot-list' : cela indique qu'Angular doit rediriger l'utilisateur vers une autre route lorsqu'il arrive sur cette route. Dans ce cas, la redirection est faite vers la route '/app-spot-list'.
    RouterModule.forRoot([
      {
        path: '',
        pathMatch: 'full',
        redirectTo: '/app-spot-list',
      },

      {
        path: 'spot-detail/:id',
        component: SpotDetailComponent,
      },
      {
        path: 'hello',
        component: HelloComponent,
      },
      {
        path: 'app-spot-list',
        component: SpotListComponent,
      },
      {
        path: 'app-spot-item',
        component: SpotItemComponent,
      },
      {
        path: '**',
        redirectTo: '/app-spot-list',
      },
    ]),
  ],
  declarations: [
    AppComponent,
    HelloComponent,
    SpotListComponent,
    SeparatePipe,
    SpotItemComponent,
    SpotDetailComponent,
    MapsUrlPipe,
  ],
  //   En Angular, le système d'injection de dépendances est utilisé pour fournir des instances de classes ou de services aux composants et aux autres parties de l'application. Le mécanisme d'injection de dépendances s'appuie sur le concept de fournisseurs (providers) qui sont des objets qui définissent comment les instances de ces classes ou services doivent être créées et rendues disponibles pour l'injection.

  // En d'autres termes, les fournisseurs sont utilisés pour configurer et fournir des instances de classes ou de services à l'application Angular, de manière centralisée et modulaire, afin de faciliter la gestion et la maintenance de l'application.
  providers: [SpotServiceService, SeparatePipe],
  //j'ai due rajouter separate Pipe aux providers car j'avais l'erreur
  bootstrap: [AppComponent],
})
export class AppModule {}
