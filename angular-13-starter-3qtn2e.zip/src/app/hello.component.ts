import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: '<div>Hello!</div>',
  styles: ['div { color: red; }'],
})
export class HelloComponent {}
