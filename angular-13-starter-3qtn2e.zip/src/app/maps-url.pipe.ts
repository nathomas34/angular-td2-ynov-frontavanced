import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Spot } from './spot-list/spot-list.interface';

@Pipe({
  name: 'mapsUrl',
})
export class MapsUrlPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}
  transform(spot: Spot): SafeResourceUrl {
    const lon = spot.location.value.coordinates[0];
    const lat = spot.location.value.coordinates[1];
    const url = `https://www.openstreetmap.org/export/embed.html?bbox=${lon}%2C${lat}`;
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
