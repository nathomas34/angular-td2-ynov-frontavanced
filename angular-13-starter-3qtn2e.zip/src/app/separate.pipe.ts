import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'separate',
  pure: true,
})
export class SeparatePipe implements PipeTransform {
  transform(value: string[], separator: string = ', '): string {
    const last = value.pop(); // retire la dernière valeur du tableau
    const result = value.join(separator); // joint les valeurs avec le séparator
    if (last) {
      return `${result} et ${last}`; // ajoute "et" avant la dernière valeur si elle existe
    }
    return result;
  }
}
