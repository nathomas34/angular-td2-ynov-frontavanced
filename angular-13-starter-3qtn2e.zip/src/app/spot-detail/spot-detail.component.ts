import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Spot } from '../spot-list/spot-list.interface';
import { SpotServiceService } from '../spot-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SeparatePipe } from '../separate.pipe';

@Component({
  selector: 'app-spot-detail',
  templateUrl: './spot-detail.component.html',
  styleUrls: ['./spot-detail.component.css'],
})
export class SpotDetailComponent implements OnInit {
  constructor(
    private ServSpot: SpotServiceService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private separate: SeparatePipe
  ) {
    this.shareForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      message: ['', Validators.required],
    });
  }

  showShareForm = false;
  shareForm: FormGroup;
  spot: Spot;

  ngOnInit() {
    this.ServSpot.getDetailSpot(this.route.snapshot.params['id']).subscribe(
      (data) => {
        this.spot = data[0];
      }
    );
  }

  backClicked() {
    this.router.navigate(['/spot-list']);
  }

  get email() {
    return this.shareForm.get('email');
  }

  get message() {
    return this.shareForm.get('message');
  }
  separateAllowedVehicleType(arr: string[]): string {
    return this.separate.transform(arr, ',');
  }

  onSubmit() {
    if (this.shareForm.valid) {
      console.log(typeof this.spot.allowedVehicleType.value);
      console.log(
        `La fiche du parking ${this.spot.name.value} qui est actuellement ${
          this.spot.status.value
        }, contenant ${
          this.spot.availableSpotNumber.value
        } places, disponible à ${
          (this.spot.availableSpotNumber.value * 100) /
          this.spot.totalSpotNumber.value
        }, %, contenant des places pour ${this.separateAllowedVehicleType(
          this.spot.allowedVehicleType.value
        )} dont la dernière mise à jour des données a été faite le ${
          this.spot.status.metadata.timestamp.value
        } est partagée à ${this.email.value} avec le message suivant : ${
          this.message.value
        }`
      );
      this.shareForm.reset();
      this.showShareForm = false;
    } else {
      console.error('Le formulaire est invalide');
    }
  }
}
