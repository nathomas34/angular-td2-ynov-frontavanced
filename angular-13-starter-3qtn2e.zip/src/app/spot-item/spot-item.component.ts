import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Spot } from '../spot-list/spot-list.interface';

@Component({
  selector: 'app-spot-item',
  templateUrl: './spot-item.component.html',
  styleUrls: ['./spot-item.component.css'],
})
export class SpotItemComponent {
  @Input() spot: Spot;
  @Output() like = new EventEmitter<Spot>();
  availableSpotNumber: number = 0;
  ngOnChanges() {
    if (
      (this.spot.availableSpotNumber.value * 100) /
        this.spot.totalSpotNumber.value <=
      25
    ) {
      this.availableSpotNumber = this.spot.availableSpotNumber.value;
      console.log(this.spot.name.value + ' à moins de 25% de disponibilité');
    }
  }

  onLike(): void {
    this.like.emit(this.spot);
  }
}
