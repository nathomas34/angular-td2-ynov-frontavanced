import { Component, OnInit } from '@angular/core';
import { SpotServiceService } from '../spot-service.service';
import { Spot } from './spot-list.interface';

@Component({
  selector: 'app-spot-list',
  templateUrl: './spot-list.component.html',
  styleUrls: ['./spot-list.component.css'],
})
export class SpotListComponent implements OnInit {
  constructor(private ServSpot: SpotServiceService) {}
  trackByFn(index, item) {
    return index;
  }
  liste: any;
  ngOnInit() {
    this.ServSpot.getSpot().subscribe((data) => {
      this.liste = data;
    });
  }
  onLike(spot: Spot): void {
    console.log(`la place : ${spot.name.value} est votre place favorite`);
  }
}
