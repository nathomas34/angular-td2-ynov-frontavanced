import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Spot } from './spot-list/spot-list.interface';

@Injectable()
export class SpotServiceService {
  constructor(private http: HttpClient) {}

  getSpot() {
    return this.http.get<Spot>(
      'https://portail-api-data.montpellier3m.fr/offstreetparking?limit=100'
    );
  }
  getDetailSpot(id: string) {
    return this.http.get<Spot>(
      'https://portail-api-data.montpellier3m.fr/offstreetparking?id=' + id
    );
  }
}
